clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f00.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f01.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f02.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f03.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f04.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f05.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f06.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f07.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f08.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f09.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f10.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f11.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f12.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f13.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f14.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f15.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f16.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f17.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f18.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f19.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f20.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f21.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f22.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f23.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0005f24.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
