i=1;
j=1;
k=0;
for j=1:18;
    k=k+0.05;
    g=0;
    f=0;
for i=1:26;
    if d3(i,1)>k
        g=g+1;
    else
        f=f+1;
    end
end
Far(j,1)=f/25;
end
i1=1;
j1=1;
k1=0;
for j1=1:18;
    k1=k1+0.05;
    g1=0;
    f1=0;
for i1=1:26;
    if d4(i1,1)<k1
        g1=g1+1;
    else
        f1=f1+1;
    end
end
Far1(j1,1)=f1/25;
end
x=0.05:0.05:0.9
plot(x,Far)
hold on
plot(x,Far1)
hold off



