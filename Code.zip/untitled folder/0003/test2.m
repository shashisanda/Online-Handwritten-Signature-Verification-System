clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f00.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f01.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f02.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f03.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f04.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f05.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f06.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f07.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f08.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f09.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f10.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f11.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f12.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f13.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f14.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f15.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f16.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f17.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f18.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f19.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f20.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f21.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f22.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f23.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003f24.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
