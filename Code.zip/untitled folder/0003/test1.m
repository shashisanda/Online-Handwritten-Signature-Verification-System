clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v00.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v01.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v02.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v03.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v04.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v05.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v06.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v07.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v08.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v09.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v10.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v11.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v12.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v13.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v14.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v15.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v16.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v17.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v18.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v19.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v20.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v21.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v22.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v23.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0003v24.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
