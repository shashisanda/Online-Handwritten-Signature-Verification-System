function Input=in(a1)
dx=abs([diff(a1(:,1))]);
dy=abs([diff(a1(:,2))]);
dz=abs([diff(a1(:,3))]);
dq=abs([diff(a1(:,4))]);
dp=abs([diff(a1(:,5))]);

d2x=abs(diff(dx));
d2x(numel(dx)) = 0;
d2y=abs(diff(dy));
d2y(numel(dy)) = 0;

for i= 1:length(dx)-1
    sin(i,1)=dy(i,1)/sqrt((dx(i,1).^2)+(dy(i,1).^2));
    cos(i,1)=dx(i,1)/sqrt((dx(i,1).^2)+(dy(i,1).^2));
end
sin(numel(dx)) = 0;
cos(numel(dx)) = 0;

l=sqrt((dx.^2)+(dy.^2));
dl=sqrt((d2x.^2)+(d2y.^2));
l(numel(dx)) = 0;
dl(numel(dx)) = 0;
Input=[dx dy dz dq dp d2x d2y sin cos l dl];