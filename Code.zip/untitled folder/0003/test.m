clc
clear all
[x,y,z,az,in,pps]= FPG_Signature_Read('0001f24.fpg', 1, 1);
a1(:,1) = (x-min(x))/(max(x)-min(x));
a1(:,2) = (y-min(y))/(max(y)-min(y));
a1(:,3) = (z-min(z))/(max(z)-min(z));
a1(:,4) = (az-min(az))/(max(az)-min(az));
a1(:,5) = (in-min(in))/(max(in)-min(in));


dx=abs([diff(a1(:,1))]);
dy=abs([diff(a1(:,2))]);
dz=abs([diff(a1(:,3))]);
dq=abs([diff(a1(:,4))]);
dp=abs([diff(a1(:,5))]);

d2x=abs(diff(dx));
d2y=abs(diff(dy));

for i= 1:length(dx)-1
    sin(i,1)=dy(i,1)/sqrt((dx(i,1).^2)+(dy(i,1).^2));
    cos(i,1)=dx(i,1)/sqrt((dx(i,1).^2)+(dy(i,1).^2));
end

l=sqrt((dx.^2)+(dy.^2));
dl=sqrt((d2x.^2)+(d2y.^2));




