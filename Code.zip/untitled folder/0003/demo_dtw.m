mex dtw_c.c;

a=rand(500,3);
b=rand(520,3);
w=50;

tic;
d1=dtw(a,b,w);
t1=toc;

tic;
d2=dtw_c(a,b,w);
t2=toc;

fprintf('Using Matlab version: distance=%f, running time=%f\n',d1,t1);
fprintf('Using C/MEX version: distance=%f, running time=%f\n',d2,t2);

