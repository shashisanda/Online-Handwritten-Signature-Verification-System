function [D,Mu1, Variances1, Probability_of_Cluster_given_Point1]=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
a11(:,1) = (x1-min(x1))/(max(x1)-min(x1));
a11(:,2) = (y1-min(y1))/(max(y1)-min(y1));
a11(:,3) = (z1-min(z1))/(max(z1)-min(z1));
a11(:,4) = (az1-min(az1))/(max(az1)-min(az1));
a11(:,5) = (in1-min(in1))/(max(in1)-min(in1));

dx1=abs([diff(a11(:,1))]);
dy1=abs([diff(a11(:,2))]);
dz1=abs([diff(a11(:,3))]);
dq1=abs([diff(a11(:,4))]);
dp1=abs([diff(a11(:,5))]);

d2x1=abs(diff(dx1));
d2x1(numel(dx1)) = 0;
d2y1=abs(diff(dy1));
d2y1(numel(dy1)) = 0;

for i= 1:length(dx1)-1
    sin1(i,1)=dy1(i,1)/sqrt((dx1(i,1).^2)+(dy1(i,1).^2));
    cos1(i,1)=dx1(i,1)/sqrt((dx1(i,1).^2)+(dy1(i,1).^2));
end
sin1(numel(dx1)) = 0;
cos1(numel(dx1)) = 0;

l1=sqrt((dx1.^2)+(dy1.^2));
dl1=sqrt((d2x1.^2)+(d2y1.^2));
l1(numel(dx1)) = 0;
dl1(numel(dx1)) = 0;
Input1=[dx1 dy1 dz1 dq1 dp1 d2x1 d2y1 sin1 cos1 l1 dl1];
Input1(isnan(Input1))=0.5;

No_of_Clusters1 = 2;
No_of_Iterations1 = 5;
[INDEX1,Mu1, Variances1, Probability_of_Cluster_given_Point1] = GMM(Input1, No_of_Clusters1,No_of_Iterations1);
w=50;
P2=Probability_of_Cluster_given_Point1;
P11=[P1(1,:),P1(2,:)]
P22=[P2(1,:),P2(2,:)]
load('testscore.mat');
[k1,k2]=size(d3);
d3(k1+1,1)=dtw(P11,P22,w)/5;
D=median(pdist(Input));
if d3(k1+1,1)>D
    d3(k1+1,k2)=1
else
    d3(k1+1,k2)=0
end
save('testscore.mat','d3')
close all

