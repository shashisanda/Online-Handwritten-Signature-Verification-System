i=1;
j=1;
k=0;
for j=1:45;
    k=k+0.02;
    g=0;
    f=0;
for i=1:26
    if t1(i,1)>k
        g=g+1;
    else
        f=f+1;
    end
end
Far(j,1)=f/25;
end
i1=1;
j1=1;
k1=0;
for j1=1:45;
    k1=k1+0.02;
    g1=0;
    f1=0;
for i1=1:26;
    if t2(i1,1)<k1
        g1=g1+1;
    else
        f1=f1+1;
    end
end
Far1(j1,1)=f1/25;
end
x=0.01:0.02:0.9
figure
plot(x,Far)
hold on
plot(x,Far1)
hold off
figure
flipud(Far1)
Far1=ans
plot(Far,Far1)



