function [P1,Input]=sha(w)
[s1(:,1),s1(:,2),s1(:,3),s1(:,4),s1(:,5)]= FPG_Signature_Read('0007v00.fpg');
[s2(:,1),s2(:,2),s2(:,3),s2(:,4),s2(:,5)]= FPG_Signature_Read('0007v01.fpg');
[s3(:,1),s3(:,2),s3(:,3),s3(:,4),s3(:,5)]= FPG_Signature_Read('0007v02.fpg');
[s4(:,1),s4(:,2),s4(:,3),s4(:,4),s4(:,5)]= FPG_Signature_Read('0007v03.fpg');
[s5(:,1),s5(:,2),s5(:,3),s5(:,4),s5(:,5)]= FPG_Signature_Read('0007v04.fpg');
for i=1:5
a1(:,i) = [(s1(:,i)-min(s1(:,i)))/(max(s1(:,i))-min(s1(:,i))),
           (s2(:,i)-min(s2(:,i)))/(max(s2(:,i))-min(s2(:,i))),
           (s3(:,i)-min(s3(:,i)))/(max(s3(:,i))-min(s3(:,i))),
           (s4(:,i)-min(s4(:,i)))/(max(s4(:,i))-min(s4(:,i))),
           (s5(:,i)-min(s5(:,i)))/(max(s5(:,i))-min(s5(:,i)))]
end

dx=abs([diff(a1(:,1))]);
dy=abs([diff(a1(:,2))]);
dz=abs([diff(a1(:,3))]);
dq=abs([diff(a1(:,4))]);
dp=abs([diff(a1(:,5))]);

d2x=abs(diff(dx));
d2x(numel(dx)) = 0;
d2y=abs(diff(dy));
d2y(numel(dy)) = 0;

for i= 1:length(dx)-1
    sin(i,1)=dy(i,1)/sqrt((dx(i,1).^2)+(dy(i,1).^2));
    cos(i,1)=dx(i,1)/sqrt((dx(i,1).^2)+(dy(i,1).^2));
end
sin(numel(dx)) = 0;
cos(numel(dx)) = 0;

l=sqrt((dx.^2)+(dy.^2));
dl=sqrt((d2x.^2)+(d2y.^2));
l(numel(dx)) = 0;
dl(numel(dx)) = 0;
Input=[dx dy dz dq dp d2x d2y sin cos l dl];
Input(isnan(Input))=0.3;
No_of_Clusters = 2;
No_of_Iterations = 5;
[INDEX,Mu, Variances, Probability_of_Cluster_given_Point] = GMM(Input, No_of_Clusters,No_of_Iterations);
P1=Probability_of_Cluster_given_Point;
