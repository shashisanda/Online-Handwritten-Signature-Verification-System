clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f00.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f01.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f02.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f03.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f04.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f05.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f06.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f07.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f08.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f09.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f10.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f11.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f12.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f13.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f14.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f15.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f16.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f17.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f18.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f19.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f20.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f21.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f22.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f23.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0007f24.fpg');
D=testGMM2(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
