clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v00.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v01.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v02.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v03.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v04.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v05.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v06.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input)
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v07.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v08.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v09.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v10.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v11.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v12.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v13.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v14.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v15.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v16.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v17.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v18.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v19.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v20.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v21.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v22.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v23.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
clear all
w=1;[P1,Input]=sha(w);
[x1,y1,z1,az1,in1,pps1]= FPG_Signature_Read('0004v24.fpg');
D=testGMM1(x1,y1,z1,az1,in1,pps1,P1,Input);
close all
