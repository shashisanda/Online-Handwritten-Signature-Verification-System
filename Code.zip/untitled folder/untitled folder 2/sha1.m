i1=1;
j1=1;
k1=0;
for j1=1:45
    k1=k1+0.02;
    g=0;
    f=0;
for i1=202:226
    if t1(i1,1)>k1
        g=g+1;
    else
        f=f+1;
    end
end
F1(j1,1)=f/25;
end
i2=1;
j2=1;
k2=0;
for j2=1:45
    k2=k2+0.02;
    g1=0;
    f1=0;
for i2=202:226;
    if t2(i2,1)<k2
        g1=g1+1;
    else
        f1=f1+1;
    end
end
F2(j2,1)=f1/25;
end
%%
i3=1;
j3=1;
k3=0;
for j3=1:45
    k3=k3+0.02;
    g=0;
    f=0;
for i3=1:26
    if d3(i3,1)>k3
        g=g+1;
    else
        f=f+1;
    end
end
F3(j3,1)=f/25;
end
i4=1;
j4=1;
k4=0;
for j4=1:45
    k4=k4+0.02;
    g1=0;
    f1=0;
for i4=1:26;
    if d4(i4,1)<k4
        g1=g1+1;
    else
        f1=f1+1;
    end
end
F4(j4,1)=f1/25;
end
%%
x=0.01:0.02:0.9
figure
plot(x,F1)
hold on
plot(x,F3)
hold off
legend('GMM-LCSS','GMM-DTW')
title('False Rejection Rate')
xlabel('threshold')
ylabel('False Rejection Rate(FRR)')

figure
plot(x,F2)
hold on
plot(x,F4)
hold off
legend('GMM-LCSS','GMM-DTW')

title('False Acceptance Rate')
xlabel('threshold')
ylabel('False Acceptance Rate(FAR)')

figure
plot(x,F1)
hold on
plot(x,F2)
hold off
legend('FRR','FAR')
title('LCSS---> FAR and FRR')
xlabel('Threshold')
ylabel('percentage of times a FAR and FRR')

figure
plot(x,F3)
hold on
plot(x,F4)
hold off
legend('FRR','FAR')
title('DTW---> FAR and FRR')
xlabel('Threshold')
ylabel('percentage of times a FAR and FRR')

figure
F2=flipud(F2)
plot(F1,F2)
legend('ROC-->GMM-LCSS')
title('ROC-->GMM-LCSS')
xlabel('False positive rate')
ylabel('True positive rate')
figure
F4=flipud(F4)
plot(F3,F4)
legend('ROC-->GMM-DTW')
title('ROC-->GMM-DTW')
xlabel('False positive rate')
ylabel('True positive rate')
figure
plot(F1,F2)
hold on
plot(F3,F4)
hold off
legend('ROC-->GMM-LCSS','ROC-->GMM-DTW')
title('ROC-->GMM-LCSS and GMM-DTW')
xlabel('False positive rate')
ylabel('True positive rate')
